define(function() {
  return {
    founded: 1934,
    hq: {
      number: 1700,
      street: 'Broadway',
      city: 'New York',
      state: 'New York',
      country: 'USA'
    }
  };
});
