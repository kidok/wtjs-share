define(function() {
  return function(num) {
  };
});
