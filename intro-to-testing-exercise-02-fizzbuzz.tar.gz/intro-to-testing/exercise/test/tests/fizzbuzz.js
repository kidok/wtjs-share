/*

FizzBuzz is a common interview question for developers. The developer's task is
to write a function that takes a number as its sole argument. The function
should:

- return `'fizzbuzz'` if the number is evenly divisible by 3 and 5
- return `'fizz'` if the number is evenly divisible by 3
- return `'buzz'` if the number is evenly divisible by 5
- return the number if none of the other conditions are true

For this exercise, write a test that will prove that a developer's answer to
this interview question actually works. Then, write an implementation of
FizzBuzz that makes the test pass.

*/

define(['modules/fizzbuzz'], function(fizzBuzz) {
  module('fizzBuzz');

  // Your tests go here

});
