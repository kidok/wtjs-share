/*

Write tests for a module that acts as a simple data store; then, write the
module. The module should provide the following API:

It should be possible to initialize the data store with data:

    var ds = new DataStore([ 'a', 'b', 'c' ]);

It should be possible to fetch data that matches certain criteria:

    ds.fetch(function(el) { return el > 'a' });

It should be possible to add data to the store:

    ds.add('d');

It should be possible to remove data that matches certain criteria:

    ds.remove(function(el) { return el === 'b' });

It should be possible to find out how many items are in the data store:

    ds.length

*/

define(['modules/data-store'], function(DataStore) {
  module('DataStore');

  // Your tests go here

});
